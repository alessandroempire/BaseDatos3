
table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
NATION                                            
N_REGIONKEY                                       
         5          0                             
                                                  
NATION                                            
N_REGIONKEY                                       
        10          1                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
NATION                                            
N_REGIONKEY                                       
        15          2                             
                                                  
NATION                                            
N_REGIONKEY                                       

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
        20          3                             
                                                  
NATION                                            
N_REGIONKEY                                       
        25          4                             
                                                  
NATION                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
N_NATIONKEY                                       
         0          0                             
                                                  
NATION                                            
N_NAME                                            
         0 3.3905E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
NATION                                            
N_COMMENT                                         
         0 1.6827E+35                             
                                                  
NATION                                            
N_NATIONKEY                                       
         1         24                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
NATION                                            
N_NAME                                            
         1 4.4802E+35                             
                                                  
NATION                                            
N_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
         1 6.2893E+35                             
                                                  

11 rows selected.


table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
REGION                                            
R_REGIONKEY                                       
         0          0                             
                                                  
REGION                                            
R_NAME                                            
         0 3.3893E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
REGION                                            
R_COMMENT                                         
         0 5.3686E+35                             
                                                  
REGION                                            
R_REGIONKEY                                       

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
         1          4                             
                                                  
REGION                                            
R_NAME                                            
         1 4.0129E+35                             
                                                  
REGION                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
R_COMMENT                                         
         1 6.0964E+35                             
                                                  

6 rows selected.


table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
LINEITEM                                          
L_RETURNFLAG                                      
      1393 3.3750E+35                             
                                                  
LINEITEM                                          
L_RETURNFLAG                                      
      4172 4.0500E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
LINEITEM                                          
L_RETURNFLAG                                      
      5537 4.2577E+35                             
                                                  
LINEITEM                                          
L_LINESTATUS                                      

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      2791 3.6346E+35                             
                                                  
LINEITEM                                          
L_LINESTATUS                                      
      5537 4.1019E+35                             
                                                  
LINEITEM                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
L_SHIPMODE                                        
       788 3.3899E+35                             
                                                  
LINEITEM                                          
L_SHIPMODE                                        
      1567 3.6507E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
LINEITEM                                          
L_SHIPMODE                                        
      2404 4.0113E+35                             
                                                  
LINEITEM                                          
L_SHIPMODE                                        
      3203 4.2709E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
LINEITEM                                          
L_SHIPMODE                                        
      4004 4.2717E+35                             
                                                  
LINEITEM                                          
L_SHIPMODE                                        

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      4789 4.3243E+35                             
                                                  
LINEITEM                                          
L_SHIPMODE                                        
      5537 4.3782E+35                             
                                                  
LINEITEM                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SYS_NC00017$                                      
         0      813.6                             
                                                  
LINEITEM                                          
L_ORDERKEY                                        
         0          1                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
LINEITEM                                          
L_PARTKEY                                         
         0          1                             
                                                  
LINEITEM                                          
L_SUPPKEY                                         
         0          1                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
LINEITEM                                          
L_LINENUMBER                                      
         0          1                             
                                                  
LINEITEM                                          
L_QUANTITY                                        

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
         0          1                             
                                                  
LINEITEM                                          
L_EXTENDEDPRICE                                   
         0        901                             
                                                  
LINEITEM                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
L_DISCOUNT                                        
         0          0                             
                                                  
LINEITEM                                          
L_TAX                                             
         0          0                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
LINEITEM                                          
L_SHIPDATE                                        
         0    2448624                             
                                                  
LINEITEM                                          
L_COMMITDATE                                      
         0    2448653                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
LINEITEM                                          
L_RECEIPTDATE                                     
         0    2448626                             
                                                  
LINEITEM                                          
L_SHIPINSTRUCT                                    

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
         0 3.4949E+35                             
                                                  
LINEITEM                                          
L_COMMENT                                         
         0 1.6787E+35                             
                                                  
LINEITEM                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SYS_NC00017$                                      
         1   104649.5                             
                                                  
LINEITEM                                          
L_ORDERKEY                                        
         1    6000000                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
LINEITEM                                          
L_PARTKEY                                         
         1     200000                             
                                                  
LINEITEM                                          
L_SUPPKEY                                         
         1      10000                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
LINEITEM                                          
L_LINENUMBER                                      
         1          7                             
                                                  
LINEITEM                                          
L_QUANTITY                                        

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
         1         50                             
                                                  
LINEITEM                                          
L_EXTENDEDPRICE                                   
         1   104949.5                             
                                                  
LINEITEM                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
L_DISCOUNT                                        
         1         .1                             
                                                  
LINEITEM                                          
L_TAX                                             
         1        .08                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
LINEITEM                                          
L_SHIPDATE                                        
         1    2451149                             
                                                  
LINEITEM                                          
L_COMMITDATE                                      
         1    2451118                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
LINEITEM                                          
L_RECEIPTDATE                                     
         1    2451179                             
                                                  
LINEITEM                                          
L_SHIPINSTRUCT                                    

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
         1 4.3748E+35                             
                                                  
LINEITEM                                          
L_COMMENT                                         
         1 6.3594E+35                             
                                                  

40 rows selected.


table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
ORDERS                                            
O_ORDERSTATUS                                     
      2660 3.6346E+35                             
                                                  
ORDERS                                            
O_ORDERSTATUS                                     
      5418 4.1019E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
ORDERS                                            
O_ORDERSTATUS                                     
      5562 4.1538E+35                             
                                                  
ORDERS                                            
O_ORDERPRIORITY                                   

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      1151 2.5534E+35                             
                                                  
ORDERS                                            
O_ORDERPRIORITY                                   
      2336 2.6053E+35                             
                                                  
ORDERS                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
O_ORDERPRIORITY                                   
      3386 2.6573E+35                             
                                                  
ORDERS                                            
O_ORDERPRIORITY                                   
      4475 2.7092E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
ORDERS                                            
O_ORDERPRIORITY                                   
      5562 2.7611E+35                             
                                                  
ORDERS                                            
O_ORDERKEY                                        
         0          1                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
ORDERS                                            
O_CUSTKEY                                         
         0          1                             
                                                  
ORDERS                                            
O_TOTALPRICE                                      

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
         0     857.71                             
                                                  
ORDERS                                            
O_ORDERDATE                                       
         0    2448623                             
                                                  
ORDERS                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
O_CLERK                                           
         0 3.5008E+35                             
                                                  
ORDERS                                            
O_SHIPPRIORITY                                    
         0          0                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
ORDERS                                            
O_COMMENT                                         
         0 1.6787E+35                             
                                                  
ORDERS                                            
O_ORDERKEY                                        
         1    6000000                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
ORDERS                                            
O_CUSTKEY                                         
         1     149999                             
                                                  
ORDERS                                            
O_TOTALPRICE                                      

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
         1  555285.16                             
                                                  
ORDERS                                            
O_ORDERDATE                                       
         1    2451028                             
                                                  
ORDERS                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
O_CLERK                                           
         1 3.5008E+35                             
                                                  
ORDERS                                            
O_SHIPPRIORITY                                    
         1          0                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
ORDERS                                            
O_COMMENT                                         
         1 6.3594E+35                             
                                                  

22 rows selected.


table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PARTSUPPLIER                                      
PS_PARTKEY                                        
         0          1                             
                                                  
PARTSUPPLIER                                      
PS_SUPPKEY                                        
         0          1                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PARTSUPPLIER                                      
PS_AVAILQTY                                       
         0          1                             
                                                  
PARTSUPPLIER                                      
PS_SUPPCOST                                       

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
         0          1                             
                                                  
PARTSUPPLIER                                      
PS_COMMENT                                        
         0 1.6787E+35                             
                                                  
PARTSUPPLIER                                      

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PS_PARTKEY                                        
         1     200000                             
                                                  
PARTSUPPLIER                                      
PS_SUPPKEY                                        
         1      10000                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PARTSUPPLIER                                      
PS_AVAILQTY                                       
         1       9999                             
                                                  
PARTSUPPLIER                                      
PS_SUPPCOST                                       
         1       1000                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PARTSUPPLIER                                      
PS_COMMENT                                        
         1 6.3594E+35                             
                                                  

10 rows selected.


table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
CUSTOMER                                          
C_NATIONKEY                                       
       224          0                             
                                                  
CUSTOMER                                          
C_NATIONKEY                                       
       423          1                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
CUSTOMER                                          
C_NATIONKEY                                       
       649          2                             
                                                  
CUSTOMER                                          
C_NATIONKEY                                       

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       863          3                             
                                                  
CUSTOMER                                          
C_NATIONKEY                                       
      1070          4                             
                                                  
CUSTOMER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
C_NATIONKEY                                       
      1284          5                             
                                                  
CUSTOMER                                          
C_NATIONKEY                                       
      1505          6                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
CUSTOMER                                          
C_NATIONKEY                                       
      1736          7                             
                                                  
CUSTOMER                                          
C_NATIONKEY                                       
      1970          8                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
CUSTOMER                                          
C_NATIONKEY                                       
      2213          9                             
                                                  
CUSTOMER                                          
C_NATIONKEY                                       

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      2432         10                             
                                                  
CUSTOMER                                          
C_NATIONKEY                                       
      2635         11                             
                                                  
CUSTOMER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
C_NATIONKEY                                       
      2841         12                             
                                                  
CUSTOMER                                          
C_NATIONKEY                                       
      3051         13                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
CUSTOMER                                          
C_NATIONKEY                                       
      3258         14                             
                                                  
CUSTOMER                                          
C_NATIONKEY                                       
      3475         15                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
CUSTOMER                                          
C_NATIONKEY                                       
      3710         16                             
                                                  
CUSTOMER                                          
C_NATIONKEY                                       

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      3934         17                             
                                                  
CUSTOMER                                          
C_NATIONKEY                                       
      4179         18                             
                                                  
CUSTOMER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
C_NATIONKEY                                       
      4389         19                             
                                                  
CUSTOMER                                          
C_NATIONKEY                                       
      4595         20                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
CUSTOMER                                          
C_NATIONKEY                                       
      4810         21                             
                                                  
CUSTOMER                                          
C_NATIONKEY                                       
      5014         22                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
CUSTOMER                                          
C_NATIONKEY                                       
      5237         23                             
                                                  
CUSTOMER                                          
C_NATIONKEY                                       

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      5471         24                             
                                                  
CUSTOMER                                          
C_MKTSEGMENT                                      
      1086 3.3923E+35                             
                                                  
CUSTOMER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
C_MKTSEGMENT                                      
      2162 3.4442E+35                             
                                                  
CUSTOMER                                          
C_MKTSEGMENT                                      
      3263 3.6519E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
CUSTOMER                                          
C_MKTSEGMENT                                      
      4394 3.7545E+35                             
                                                  
CUSTOMER                                          
C_MKTSEGMENT                                      
      5471 4.0113E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
CUSTOMER                                          
C_CUSTKEY                                         
         0          1                             
                                                  
CUSTOMER                                          
C_NAME                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
         0 3.5027E+35                             
                                                  
CUSTOMER                                          
C_ADDRESS                                         
         0 1.6681E+35                             
                                                  
CUSTOMER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
C_PHONE                                           
         0 2.5540E+35                             
                                                  
CUSTOMER                                          
C_ACCTBAL                                         
         0    -999.99                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
CUSTOMER                                          
C_COMMENT                                         
         0 1.6787E+35                             
                                                  
CUSTOMER                                          
C_CUSTKEY                                         
         1     150000                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
CUSTOMER                                          
C_NAME                                            
         1 3.5027E+35                             
                                                  
CUSTOMER                                          
C_ADDRESS                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
         1 6.3594E+35                             
                                                  
CUSTOMER                                          
C_PHONE                                           
         1 2.6587E+35                             
                                                  
CUSTOMER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
C_ACCTBAL                                         
         1    9999.99                             
                                                  
CUSTOMER                                          
C_COMMENT                                         
         1 6.3594E+35                             
                                                  

42 rows selected.


table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_NATIONKEY                                       
       420          0                             
                                                  
SUPPLIER                                          
S_NATIONKEY                                       
       833          1                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_NATIONKEY                                       
      1230          2                             
                                                  
SUPPLIER                                          
S_NATIONKEY                                       

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      1642          3                             
                                                  
SUPPLIER                                          
S_NATIONKEY                                       
      2057          4                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_NATIONKEY                                       
      2437          5                             
                                                  
SUPPLIER                                          
S_NATIONKEY                                       
      2839          6                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_NATIONKEY                                       
      3235          7                             
                                                  
SUPPLIER                                          
S_NATIONKEY                                       
      3650          8                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_NATIONKEY                                       
      4055          9                             
                                                  
SUPPLIER                                          
S_NATIONKEY                                       

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      4448         10                             
                                                  
SUPPLIER                                          
S_NATIONKEY                                       
      4886         11                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_NATIONKEY                                       
      5263         12                             
                                                  
SUPPLIER                                          
S_NATIONKEY                                       
      5625         13                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_NATIONKEY                                       
      6001         14                             
                                                  
SUPPLIER                                          
S_NATIONKEY                                       
      6374         15                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_NATIONKEY                                       
      6780         16                             
                                                  
SUPPLIER                                          
S_NATIONKEY                                       

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      7201         17                             
                                                  
SUPPLIER                                          
S_NATIONKEY                                       
      7608         18                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_NATIONKEY                                       
      8006         19                             
                                                  
SUPPLIER                                          
S_NATIONKEY                                       
      8417         20                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_NATIONKEY                                       
      8816         21                             
                                                  
SUPPLIER                                          
S_NATIONKEY                                       
      9217         22                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_NATIONKEY                                       
      9607         23                             
                                                  
SUPPLIER                                          
S_NATIONKEY                                       

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
     10000         24                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       230 6.0952E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
       231 6.0956E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       232 6.0964E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
       233 6.0970E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       234 6.0970E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       235 6.0974E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       236 6.0974E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       237 6.0974E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
       238 6.0982E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       239 6.0984E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
       240 6.0984E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       241 6.0985E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       242 6.1475E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       243 6.1986E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       244 6.2513E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
       245 6.2892E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       246 6.2892E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
       247 6.2892E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       248 6.2893E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       249 6.2893E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       250 6.2893E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       251 6.2893E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
       252 6.2920E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       253 6.3047E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
       254 6.3594E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
         1 1.6813E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
         2 1.6813E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
         3 1.6813E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
         4 1.6813E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
         5 1.6815E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
         6 1.6815E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
         7 1.6817E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
         8 1.6817E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
         9 1.6819E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
        10 1.6819E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
         0 1.6813E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
        11 1.6821E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        12 1.6821E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
        13 1.6823E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        14 1.6823E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        15 1.6823E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
        16 1.6829E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        17 1.6829E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
        18 1.6829E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        19 1.6841E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
        20 1.6843E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        21 1.6843E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        22 1.6847E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
        23 1.6847E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        24 1.6847E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
        25 1.6849E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        26 1.6849E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
        27 1.6849E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        28 1.6851E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        29 1.6851E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
        30 1.6851E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        31 1.6852E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
        32 1.6857E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        33 2.2912E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
        34 2.3950E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        35 2.3950E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        36 2.3950E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
        37 2.3950E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        38 3.2777E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
        39 5.0567E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        40 5.0567E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
        41 5.0567E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        42 5.0574E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        43 5.0575E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
        44 5.0575E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        45 5.0583E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
        46 5.0585E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        47 5.0585E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
        48 5.0589E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        49 5.0597E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        50 5.0597E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
        51 5.0597E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        52 5.0597E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
        53 5.0599E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        54 5.0612E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
        55 5.1104E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        56 5.1111E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        57 5.1469E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
        58 5.1601E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        59 5.1601E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
        60 5.1605E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        61 5.1617E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
        62 5.1622E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        63 5.1622E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        64 5.1630E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
        65 5.1630E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        66 5.1640E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
        67 5.1989E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        68 5.2129E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
        69 5.2129E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        70 5.2137E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        71 5.2508E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
        72 5.2508E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        73 5.2508E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
        74 5.2508E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        75 5.2508E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
        76 5.2536E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        77 5.2640E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        78 5.2644E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
        79 5.2650E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        80 5.2650E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
        81 5.2652E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        82 5.2662E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
        83 5.2666E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        84 5.2666E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        85 5.2666E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
        86 5.2670E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        87 5.2670E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
        88 5.2672E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        89 5.2676E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
        90 5.2676E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        91 5.2676E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        92 5.2676E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
        93 5.2676E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        94 5.2682E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
        95 5.2686E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        96 5.3169E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
        97 5.3169E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        98 5.3175E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
        99 5.3175E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       100 5.3188E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       101 5.3200E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
       102 5.3200E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       103 5.3200E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
       104 5.3546E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       105 5.3686E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       106 5.3690E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       107 5.3713E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       108 5.3719E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
       109 5.4197E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       110 5.4205E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
       111 5.4205E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       112 5.4206E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       113 5.4206E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       114 5.4717E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       115 5.4720E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
       116 5.4721E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       117 5.4723E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
       118 5.4739E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       119 5.4743E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       120 5.4743E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       121 5.4743E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       122 5.4745E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
       123 5.4745E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       124 5.4751E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
       125 5.4755E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       126 5.4755E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       127 5.4755E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       128 5.5264E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       129 5.5755E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
       130 5.5763E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       131 5.5778E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
       132 5.6143E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       133 5.6143E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       134 5.6274E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       135 5.6274E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       136 5.6282E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
       137 5.6282E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       138 5.6283E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
       139 5.6291E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       140 5.6297E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       141 5.6297E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       142 5.6313E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       143 5.6322E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
       144 5.6322E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       145 5.6322E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
       146 5.6322E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       147 5.6322E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       148 5.6322E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       149 5.6322E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       150 5.6323E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
       151 5.6794E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       152 5.7181E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
       153 5.7313E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       154 5.7313E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       155 5.7319E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       156 5.7324E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       157 5.7329E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
       158 5.7329E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       159 5.7349E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
       160 5.7349E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       161 5.7351E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       162 5.7351E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       163 5.7353E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       164 5.7700E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
       165 5.7844E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       166 5.7854E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
       167 5.7858E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       168 5.7858E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       169 5.7859E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       170 5.7869E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       171 5.7869E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
       172 5.7873E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       173 5.7873E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
       174 5.7873E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       175 5.7873E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       176 5.8219E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       177 5.8351E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       178 5.8359E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
       179 5.8365E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       180 5.8380E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
       181 5.8386E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       182 5.8911E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       183 5.8911E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       184 5.9258E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       185 5.9390E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
       186 5.9397E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       187 5.9398E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
       188 5.9398E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       189 5.9398E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       190 5.9398E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       191 5.9398E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       192 5.9406E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
       193 5.9406E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       194 5.9418E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
       195 5.9418E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       196 5.9430E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       197 5.9777E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       198 5.9777E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       199 5.9777E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
       200 5.9777E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       201 5.9777E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
       202 5.9777E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       203 5.9805E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       204 5.9805E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       205 5.9805E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       206 5.9839E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
       207 5.9925E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       208 5.9925E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
       209 5.9931E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       210 5.9931E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       211 5.9931E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       212 5.9939E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       213 5.9945E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
       214 5.9948E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       215 5.9948E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
       216 5.9958E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       217 6.0296E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       218 6.0436E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       219 6.0436E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       220 6.0442E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
       221 6.0442E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       222 6.0442E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_COMMENT                                         
       223 6.0442E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       224 6.0445E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       225 6.0456E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       226 6.0464E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       227 6.0464E+35                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_COMMENT                                         
       228 6.0464E+35                             
                                                  
SUPPLIER                                          
S_COMMENT                                         
       229 6.0464E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_SUPPKEY                                         
         0          1                             
                                                  
SUPPLIER                                          
S_NAME                                            
         0 4.3334E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_ADDRESS                                         
         0 1.6681E+35                             
                                                  
SUPPLIER                                          
S_PHONE                                           

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
         0 2.5540E+35                             
                                                  
SUPPLIER                                          
S_ACCTBAL                                         
         0    -998.22                             
                                                  
SUPPLIER                                          

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
S_SUPPKEY                                         
         1      10000                             
                                                  
SUPPLIER                                          
S_NAME                                            
         1 4.3334E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
SUPPLIER                                          
S_ADDRESS                                         
         1 6.3594E+35                             
                                                  
SUPPLIER                                          
S_PHONE                                           
         1 2.6587E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
SUPPLIER                                          
S_ACCTBAL                                         
         1    9999.72                             
                                                  

290 rows selected.


table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_BRAND                                           
       224 3.4501E+35                             
                                                  
PART                                              
P_BRAND                                           
       444 3.4501E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_BRAND                                           
       684 3.4501E+35                             
                                                  
PART                                              
P_BRAND                                           

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       900 3.4501E+35                             
                                                  
PART                                              
P_BRAND                                           
      1097 3.4501E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_BRAND                                           
      1317 3.4501E+35                             
                                                  
PART                                              
P_BRAND                                           
      1517 3.4501E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_BRAND                                           
      1747 3.4501E+35                             
                                                  
PART                                              
P_BRAND                                           
      1972 3.4501E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_BRAND                                           
      2208 3.4501E+35                             
                                                  
PART                                              
P_BRAND                                           

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      2413 3.4501E+35                             
                                                  
PART                                              
P_BRAND                                           
      2632 3.4501E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_BRAND                                           
      2859 3.4501E+35                             
                                                  
PART                                              
P_BRAND                                           
      3067 3.4501E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_BRAND                                           
      3293 3.4501E+35                             
                                                  
PART                                              
P_BRAND                                           
      3534 3.4501E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_BRAND                                           
      3763 3.4501E+35                             
                                                  
PART                                              
P_BRAND                                           

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      3952 3.4501E+35                             
                                                  
PART                                              
P_BRAND                                           
      4174 3.4501E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_BRAND                                           
      4411 3.4501E+35                             
                                                  
PART                                              
P_BRAND                                           
      4610 3.4501E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_BRAND                                           
      4825 3.4501E+35                             
                                                  
PART                                              
P_BRAND                                           
      5053 3.4501E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_BRAND                                           
      5287 3.4501E+35                             
                                                  
PART                                              
P_BRAND                                           

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      5510 3.4501E+35                             
                                                  
PART                                              
P_TYPE                                            
      3626 4.1705E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_TYPE                                            
      3668 4.1705E+35                             
                                                  
PART                                              
P_TYPE                                            
      3705 4.3253E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_TYPE                                            
      3737 4.3253E+35                             
                                                  
PART                                              
P_TYPE                                            
      3771 4.3253E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_TYPE                                            
      3804 4.3253E+35                             
                                                  
PART                                              
P_TYPE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      3841 4.3253E+35                             
                                                  
PART                                              
P_TYPE                                            
      3883 4.3253E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_TYPE                                            
      3913 4.3253E+35                             
                                                  
PART                                              
P_TYPE                                            
      3946 4.3253E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_TYPE                                            
      3981 4.3253E+35                             
                                                  
PART                                              
P_TYPE                                            
      4022 4.3253E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_TYPE                                            
      4059 4.3253E+35                             
                                                  
PART                                              
P_TYPE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      4082 4.3253E+35                             
                                                  
PART                                              
P_TYPE                                            
      4129 4.3253E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_TYPE                                            
      4166 4.3253E+35                             
                                                  
PART                                              
P_TYPE                                            
      4203 4.3253E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_TYPE                                            
      4243 4.3253E+35                             
                                                  
PART                                              
P_TYPE                                            
      4282 4.3253E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_TYPE                                            
      4318 4.3253E+35                             
                                                  
PART                                              
P_TYPE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      4361 4.3253E+35                             
                                                  
PART                                              
P_TYPE                                            
      4401 4.3253E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_TYPE                                            
      4436 4.3253E+35                             
                                                  
PART                                              
P_TYPE                                            
      4474 4.3253E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_TYPE                                            
      4506 4.3253E+35                             
                                                  
PART                                              
P_TYPE                                            
      4539 4.3253E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_TYPE                                            
      4561 4.3253E+35                             
                                                  
PART                                              
P_TYPE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      4593 4.3267E+35                             
                                                  
PART                                              
P_TYPE                                            
      4637 4.3267E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_TYPE                                            
      4677 4.3267E+35                             
                                                  
PART                                              
P_TYPE                                            
      4721 4.3267E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_TYPE                                            
      4761 4.3267E+35                             
                                                  
PART                                              
P_TYPE                                            
      4806 4.3267E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_TYPE                                            
      4842 4.3267E+35                             
                                                  
PART                                              
P_TYPE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      4878 4.3267E+35                             
                                                  
PART                                              
P_TYPE                                            
      4916 4.3267E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_TYPE                                            
      4943 4.3267E+35                             
                                                  
PART                                              
P_TYPE                                            
      4984 4.3267E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_TYPE                                            
      5021 4.3267E+35                             
                                                  
PART                                              
P_TYPE                                            
      5057 4.3267E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_TYPE                                            
      5088 4.3267E+35                             
                                                  
PART                                              
P_TYPE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      5136 4.3267E+35                             
                                                  
PART                                              
P_TYPE                                            
      5174 4.3267E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_TYPE                                            
      5219 4.3267E+35                             
                                                  
PART                                              
P_TYPE                                            
      5251 4.3267E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_TYPE                                            
      5281 4.3267E+35                             
                                                  
PART                                              
P_TYPE                                            
      5325 4.3267E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_TYPE                                            
      5359 4.3267E+35                             
                                                  
PART                                              
P_TYPE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      5393 4.3267E+35                             
                                                  
PART                                              
P_TYPE                                            
      5436 4.3267E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_TYPE                                            
      5471 4.3267E+35                             
                                                  
PART                                              
P_TYPE                                            
      5510 4.3267E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_TYPE                                            
        38 3.5963E+35                             
                                                  
PART                                              
P_TYPE                                            
        74 3.5963E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_TYPE                                            
       109 3.5963E+35                             
                                                  
PART                                              
P_TYPE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       144 3.5963E+35                             
                                                  
PART                                              
P_TYPE                                            
       174 3.5963E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_TYPE                                            
       201 3.5963E+35                             
                                                  
PART                                              
P_TYPE                                            
       229 3.5963E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_TYPE                                            
       261 3.5963E+35                             
                                                  
PART                                              
P_TYPE                                            
       291 3.5963E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_TYPE                                            
       332 3.5963E+35                             
                                                  
PART                                              
P_TYPE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       364 3.5963E+35                             
                                                  
PART                                              
P_TYPE                                            
       408 3.5963E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_TYPE                                            
       449 3.5963E+35                             
                                                  
PART                                              
P_TYPE                                            
       481 3.5963E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_TYPE                                            
       510 3.5963E+35                             
                                                  
PART                                              
P_TYPE                                            
       554 3.5963E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_TYPE                                            
       588 3.5963E+35                             
                                                  
PART                                              
P_TYPE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       624 3.5963E+35                             
                                                  
PART                                              
P_TYPE                                            
       656 3.5963E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_TYPE                                            
       708 3.5963E+35                             
                                                  
PART                                              
P_TYPE                                            
       738 3.5963E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_TYPE                                            
       786 3.5963E+35                             
                                                  
PART                                              
P_TYPE                                            
       825 3.5963E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_TYPE                                            
       856 3.5963E+35                             
                                                  
PART                                              
P_TYPE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       899 3.5963E+35                             
                                                  
PART                                              
P_TYPE                                            
       933 3.9594E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_TYPE                                            
       974 3.9594E+35                             
                                                  
PART                                              
P_TYPE                                            
      1010 3.9594E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_TYPE                                            
      1040 3.9594E+35                             
                                                  
PART                                              
P_TYPE                                            
      1088 3.9594E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_TYPE                                            
      1138 3.9594E+35                             
                                                  
PART                                              
P_TYPE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      1167 3.9594E+35                             
                                                  
PART                                              
P_TYPE                                            
      1204 3.9594E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_TYPE                                            
      1237 3.9594E+35                             
                                                  
PART                                              
P_TYPE                                            
      1268 3.9594E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_TYPE                                            
      1297 3.9594E+35                             
                                                  
PART                                              
P_TYPE                                            
      1328 3.9594E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_TYPE                                            
      1358 3.9594E+35                             
                                                  
PART                                              
P_TYPE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      1387 3.9594E+35                             
                                                  
PART                                              
P_TYPE                                            
      1424 3.9594E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_TYPE                                            
      1469 3.9594E+35                             
                                                  
PART                                              
P_TYPE                                            
      1509 3.9594E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_TYPE                                            
      1545 3.9594E+35                             
                                                  
PART                                              
P_TYPE                                            
      1583 3.9594E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_TYPE                                            
      1610 3.9594E+35                             
                                                  
PART                                              
P_TYPE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      1653 3.9594E+35                             
                                                  
PART                                              
P_TYPE                                            
      1688 3.9594E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_TYPE                                            
      1728 3.9594E+35                             
                                                  
PART                                              
P_TYPE                                            
      1761 3.9594E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_TYPE                                            
      1785 3.9594E+35                             
                                                  
PART                                              
P_TYPE                                            
      1818 4.0121E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_TYPE                                            
      1851 4.0121E+35                             
                                                  
PART                                              
P_TYPE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      1886 4.0121E+35                             
                                                  
PART                                              
P_TYPE                                            
      1914 4.0121E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_TYPE                                            
      1958 4.0121E+35                             
                                                  
PART                                              
P_TYPE                                            
      2009 4.0121E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_TYPE                                            
      2060 4.0121E+35                             
                                                  
PART                                              
P_TYPE                                            
      2096 4.0121E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_TYPE                                            
      2124 4.0121E+35                             
                                                  
PART                                              
P_TYPE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      2157 4.0121E+35                             
                                                  
PART                                              
P_TYPE                                            
      2194 4.0121E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_TYPE                                            
      2244 4.0121E+35                             
                                                  
PART                                              
P_TYPE                                            
      2292 4.0121E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_TYPE                                            
      2328 4.0121E+35                             
                                                  
PART                                              
P_TYPE                                            
      2370 4.0121E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_TYPE                                            
      2413 4.0121E+35                             
                                                  
PART                                              
P_TYPE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      2444 4.0121E+35                             
                                                  
PART                                              
P_TYPE                                            
      2486 4.0121E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_TYPE                                            
      2513 4.0121E+35                             
                                                  
PART                                              
P_TYPE                                            
      2541 4.0121E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_TYPE                                            
      2589 4.0121E+35                             
                                                  
PART                                              
P_TYPE                                            
      2628 4.0121E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_TYPE                                            
      2664 4.0121E+35                             
                                                  
PART                                              
P_TYPE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      2705 4.0121E+35                             
                                                  
PART                                              
P_TYPE                                            
      2753 4.0121E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_TYPE                                            
      2784 4.1705E+35                             
                                                  
PART                                              
P_TYPE                                            
      2806 4.1705E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_TYPE                                            
      2847 4.1705E+35                             
                                                  
PART                                              
P_TYPE                                            
      2883 4.1705E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_TYPE                                            
      2914 4.1705E+35                             
                                                  
PART                                              
P_TYPE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      2954 4.1705E+35                             
                                                  
PART                                              
P_TYPE                                            
      2983 4.1705E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_TYPE                                            
      3009 4.1705E+35                             
                                                  
PART                                              
P_TYPE                                            
      3045 4.1705E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_TYPE                                            
      3085 4.1705E+35                             
                                                  
PART                                              
P_TYPE                                            
      3123 4.1705E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_TYPE                                            
      3170 4.1705E+35                             
                                                  
PART                                              
P_TYPE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      3204 4.1705E+35                             
                                                  
PART                                              
P_TYPE                                            
      3242 4.1705E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_TYPE                                            
      3273 4.1705E+35                             
                                                  
PART                                              
P_TYPE                                            
      3310 4.1705E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_TYPE                                            
      3342 4.1705E+35                             
                                                  
PART                                              
P_TYPE                                            
      3386 4.1705E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_TYPE                                            
      3429 4.1705E+35                             
                                                  
PART                                              
P_TYPE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      3464 4.1705E+35                             
                                                  
PART                                              
P_TYPE                                            
      3509 4.1705E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_TYPE                                            
      3547 4.1705E+35                             
                                                  
PART                                              
P_TYPE                                            
      3583 4.1705E+35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_SIZE                                            
       115          1                             
                                                  
PART                                              
P_SIZE                                            
       228          2                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_SIZE                                            
       328          3                             
                                                  
PART                                              
P_SIZE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
       444          4                             
                                                  
PART                                              
P_SIZE                                            
       570          5                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_SIZE                                            
       671          6                             
                                                  
PART                                              
P_SIZE                                            
       775          7                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_SIZE                                            
       879          8                             
                                                  
PART                                              
P_SIZE                                            
       985          9                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_SIZE                                            
      1101         10                             
                                                  
PART                                              
P_SIZE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      1226         11                             
                                                  
PART                                              
P_SIZE                                            
      1334         12                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_SIZE                                            
      1429         13                             
                                                  
PART                                              
P_SIZE                                            
      1550         14                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_SIZE                                            
      1662         15                             
                                                  
PART                                              
P_SIZE                                            
      1775         16                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_SIZE                                            
      1886         17                             
                                                  
PART                                              
P_SIZE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      2033         18                             
                                                  
PART                                              
P_SIZE                                            
      2138         19                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_SIZE                                            
      2242         20                             
                                                  
PART                                              
P_SIZE                                            
      2334         21                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_SIZE                                            
      2431         22                             
                                                  
PART                                              
P_SIZE                                            
      2533         23                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_SIZE                                            
      2637         24                             
                                                  
PART                                              
P_SIZE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      2749         25                             
                                                  
PART                                              
P_SIZE                                            
      2852         26                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_SIZE                                            
      2971         27                             
                                                  
PART                                              
P_SIZE                                            
      3097         28                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_SIZE                                            
      3207         29                             
                                                  
PART                                              
P_SIZE                                            
      3339         30                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_SIZE                                            
      3428         31                             
                                                  
PART                                              
P_SIZE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      3531         32                             
                                                  
PART                                              
P_SIZE                                            
      3651         33                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_SIZE                                            
      3760         34                             
                                                  
PART                                              
P_SIZE                                            
      3870         35                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_SIZE                                            
      3974         36                             
                                                  
PART                                              
P_SIZE                                            
      4076         37                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_SIZE                                            
      4212         38                             
                                                  
PART                                              
P_SIZE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      4324         39                             
                                                  
PART                                              
P_SIZE                                            
      4439         40                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_SIZE                                            
      4533         41                             
                                                  
PART                                              
P_SIZE                                            
      4636         42                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_SIZE                                            
      4734         43                             
                                                  
PART                                              
P_SIZE                                            
      4840         44                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_SIZE                                            
      4964         45                             
                                                  
PART                                              
P_SIZE                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
      5073         46                             
                                                  
PART                                              
P_SIZE                                            
      5187         47                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_SIZE                                            
      5308         48                             
                                                  
PART                                              
P_SIZE                                            
      5412         49                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_SIZE                                            
      5510         50                             
                                                  
PART                                              
SYS_NC00010$                                      
         0 4.1705E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_PARTKEY                                         
         0          1                             
                                                  
PART                                              
P_NAME                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
         0 5.0585E+35                             
                                                  
PART                                              
P_MFGR                                            
         0 4.0178E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_CONTAINER                                       
         0 3.8596E+35                             
                                                  
PART                                              
P_RETAILPRICE                                     
         0        901                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_COMMENT                                         
         0 1.6787E+35                             
                                                  
PART                                              
SYS_NC00010$                                      
         1 4.1705E+35                             

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
                                                  
PART                                              
P_PARTKEY                                         
         1     200000                             
                                                  
PART                                              
P_NAME                                            

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
         1 6.3033E+35                             
                                                  
PART                                              
P_MFGR                                            
         1 4.0178E+35                             
                                                  
PART                                              

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
P_CONTAINER                                       
         1 4.5340E+35                             
                                                  
PART                                              
P_RETAILPRICE                                     
         1    2098.99                             
                                                  

table name                                        
--------------------------------------------------
columna                                           
--------------------------------------------------
    number      value                             
---------- ----------                             
PART                                              
P_COMMENT                                         
         1 6.3594E+35                             
                                                  

239 rows selected.

