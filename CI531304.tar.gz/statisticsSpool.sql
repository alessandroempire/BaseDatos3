
PL/SQL procedure successfully completed.


column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
N_NATIONKEY                                       
          25 N                                    
NONE                                              
                                                  
N_NAME                                            
          25 N                                    
NONE                                              

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
                                                  
N_REGIONKEY                                       
           5 N                                    
FREQUENCY                                         
                                                  
N_COMMENT                                         
          25 N                                    

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
NONE                                              
                                                  


PL/SQL procedure successfully completed.


column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
R_REGIONKEY                                       
           5 N                                    
NONE                                              
                                                  
R_NAME                                            
           5 N                                    
NONE                                              

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
                                                  
R_COMMENT                                         
           5 N                                    
NONE                                              
                                                  


PL/SQL procedure successfully completed.


column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
L_ORDERKEY                                        
     1479040 N                                    
NONE                                              
                                                  
L_PARTKEY                                         
      201968 N                                    
NONE                                              

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
                                                  
L_SUPPKEY                                         
       10000 N                                    
NONE                                              
                                                  
L_LINENUMBER                                      
           7 N                                    

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
NONE                                              
                                                  
L_QUANTITY                                        
          50 N                                    
NONE                                              
                                                  
L_EXTENDEDPRICE                                   

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
      943232 N                                    
NONE                                              
                                                  
L_DISCOUNT                                        
          11 N                                    
NONE                                              
                                                  

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
L_TAX                                             
           9 N                                    
NONE                                              
                                                  
L_RETURNFLAG                                      
           3 N                                    
FREQUENCY                                         

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
                                                  
L_LINESTATUS                                      
           2 N                                    
FREQUENCY                                         
                                                  
L_SHIPDATE                                        
        2526 Y                                    

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
NONE                                              
                                                  
L_COMMITDATE                                      
        2466 Y                                    
NONE                                              
                                                  
L_RECEIPTDATE                                     

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
        2554 Y                                    
NONE                                              
                                                  
L_SHIPINSTRUCT                                    
           4 Y                                    
NONE                                              
                                                  

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
L_SHIPMODE                                        
           7 Y                                    
FREQUENCY                                         
                                                  
L_COMMENT                                         
     4647936 Y                                    
NONE                                              

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
                                                  

16 rows selected.


PL/SQL procedure successfully completed.


column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
O_ORDERKEY                                        
     1500000 N                                    
NONE                                              
                                                  
O_CUSTKEY                                         
      100712 N                                    
NONE                                              

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
                                                  
O_ORDERSTATUS                                     
           3 N                                    
FREQUENCY                                         
                                                  
O_TOTALPRICE                                      
     1456384 N                                    

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
NONE                                              
                                                  
O_ORDERDATE                                       
        2406 Y                                    
NONE                                              
                                                  
O_ORDERPRIORITY                                   

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
           5 N                                    
FREQUENCY                                         
                                                  
O_CLERK                                           
        1000 N                                    
NONE                                              
                                                  

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
O_SHIPPRIORITY                                    
           1 Y                                    
NONE                                              
                                                  
O_COMMENT                                         
     1472000 Y                                    
NONE                                              

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
                                                  

9 rows selected.


PL/SQL procedure successfully completed.


column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
PS_PARTKEY                                        
      201968 N                                    
NONE                                              
                                                  
PS_SUPPKEY                                        
       10000 N                                    
NONE                                              

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
                                                  
PS_AVAILQTY                                       
        9999 N                                    
NONE                                              
                                                  
PS_SUPPCOST                                       
      100536 N                                    

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
NONE                                              
                                                  
PS_COMMENT                                        
      800000 Y                                    
NONE                                              
                                                  


PL/SQL procedure successfully completed.


column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
C_CUSTKEY                                         
      150000 N                                    
NONE                                              
                                                  
C_NAME                                            
      150000 N                                    
NONE                                              

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
                                                  
C_ADDRESS                                         
      150000 N                                    
NONE                                              
                                                  
C_NATIONKEY                                       
          25 N                                    

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
FREQUENCY                                         
                                                  
C_PHONE                                           
      150000 N                                    
NONE                                              
                                                  
C_ACCTBAL                                         

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
      141408 N                                    
NONE                                              
                                                  
C_MKTSEGMENT                                      
           5 Y                                    
FREQUENCY                                         
                                                  

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
C_COMMENT                                         
      148896 Y                                    
NONE                                              
                                                  

8 rows selected.


PL/SQL procedure successfully completed.


column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
S_SUPPKEY                                         
       10000 N                                    
NONE                                              
                                                  
S_NAME                                            
       10000 N                                    
NONE                                              

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
                                                  
S_ADDRESS                                         
       10000 N                                    
NONE                                              
                                                  
S_NATIONKEY                                       
          25 N                                    

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
FREQUENCY                                         
                                                  
S_PHONE                                           
       10000 N                                    
NONE                                              
                                                  
S_ACCTBAL                                         

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
        9955 N                                    
NONE                                              
                                                  
S_COMMENT                                         
       10000 Y                                    
HEIGHT BALANCED                                   
                                                  

7 rows selected.


PL/SQL procedure successfully completed.


column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
P_PARTKEY                                         
      200000 N                                    
NONE                                              
                                                  
P_NAME                                            
      200000 N                                    
NONE                                              

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
                                                  
P_MFGR                                            
           5 N                                    
NONE                                              
                                                  
P_BRAND                                           
          25 N                                    

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
FREQUENCY                                         
                                                  
P_TYPE                                            
         150 N                                    
FREQUENCY                                         
                                                  
P_SIZE                                            

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
          50 N                                    
FREQUENCY                                         
                                                  
P_CONTAINER                                       
          40 N                                    
NONE                                              
                                                  

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
P_RETAILPRICE                                     
       21178 N                                    
NONE                                              
                                                  
P_COMMENT                                         
      132896 Y                                    
NONE                                              

column name                                       
--------------------------------------------------
num distinct nul                                  
------------ ---                                  
histogram                                         
---------------------------------------------     
                                                  

9 rows selected.

